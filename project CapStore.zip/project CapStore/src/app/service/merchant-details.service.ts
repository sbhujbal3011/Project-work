import { Injectable } from '@angular/core';
import { CustomerModel } from '../model/customer';
import { MerchantModel } from '../model/merchant';

@Injectable({
  providedIn: 'root'
})
export class MerchantDetailsService {
   merchantArr: MerchantModel[]
 // =[ {
  //   merchantId: 1,
  //   merchantFirstName: "Product001",
  //   merchantLastName:"tgdfg",
  //   merchantEmail: "dvfxd",
  //   merchantContact:,
  //   merchantPassword : "fdd",
  //   isMerchantActivated : true
  //   }];


constructor() {
      
   

}

}

  