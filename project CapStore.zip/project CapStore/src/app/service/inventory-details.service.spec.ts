import { TestBed } from '@angular/core/testing';

import { InventoryDetailsService } from './inventory-details.service';

describe('InventoryDetailsService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: InventoryDetailsService = TestBed.get(InventoryDetailsService);
    expect(service).toBeTruthy();
  });
});
