import { Injectable } from '@angular/core';
import { InventoryModel } from '../model/inventory';
import { Router } from '@angular/router';

@Injectable({
  providedIn: 'root'
})
export class InventoryDetailsService {
  inventoryArr: InventoryModel[];

  constructor(private routes: Router) {
    this.inventoryArr = [];
  }
}
