import { Component, OnInit } from '@angular/core';
import { HttpClient, HttpParams } from '@angular/common/http';

@Component({
  selector: 'app-admin-page',
  templateUrl: './admin-page.component.html',
  styleUrls: ['./admin-page.component.css']
})
export class AdminPageComponent implements OnInit {

  constructor(private http: HttpClient) { }
  headers;
  ngOnInit() {
     this.http.get('http://localhost:8888/getAllAlbum').subscribe(data => {
      console.log(data);
    });
  }
  addAlbum() {
    this.headers = new Headers();
    this.headers.append('Content-Type', 'application/json');
    const params = new HttpParams();
    this.http.post('http://localhost:8880/add', params, { headers: this.headers})
    .subscribe(
        res => {
            console.log(res);
        },
        err => {
            console.log(err.message);
        }
    );
  }
}
