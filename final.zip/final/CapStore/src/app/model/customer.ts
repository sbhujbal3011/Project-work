export class CustomerModel {
    public customerId: number;
    public customerFirstName: string;
    public customerLastName: string;
    public customerEmail: string;
    public customerPassword: string
    public customerContact: string;
    public isCustomerActivated: boolean;
    
}
