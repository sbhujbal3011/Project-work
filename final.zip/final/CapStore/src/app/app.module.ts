import { MaterialModule } from './material.module';
import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import {BrowserAnimationsModule} from '@angular/platform-browser/animations';
import { AdminPageComponent } from './admin-page/admin-page.component';
import { CustomerDetailsComponent } from './customer-details/customer-details.component';
import { MerchantDetailsComponent } from './merchant-details/merchant-details.component';
import { InventoryDetailsComponent } from './inventory-details/inventory-details.component';
import { HttpClientModule } from '@angular/common/http';
@NgModule({
  declarations: [
    AppComponent,
    AdminPageComponent,
    CustomerDetailsComponent,
    MerchantDetailsComponent,
    InventoryDetailsComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    BrowserAnimationsModule,
    MaterialModule,
    HttpClientModule
  ],
  providers: [],
  bootstrap: [AppComponent],

})
export class AppModule {

 }
