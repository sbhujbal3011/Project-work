import { Component, OnInit } from '@angular/core';
import { InventoryModel } from '../model/inventory';
import { InventoryDetailsService } from '../service/inventory-details.service';
import { CustomerDetailsService } from '../service/customer-details.service';

@Component({
  selector: 'app-inventory-details',
  templateUrl: './inventory-details.component.html',
  styleUrls: ['./inventory-details.component.css']
})
export class InventoryDetailsComponent implements OnInit {
  inventoryArr: InventoryModel[];

  constructor(private service: CustomerDetailsService) {
    this.inventoryArr = [];
  
  }

  ngOnInit() {
    
    this.service.getInventoryDetails().subscribe(data => {
      this.inventoryArr = data;
    });
   
  }

}
