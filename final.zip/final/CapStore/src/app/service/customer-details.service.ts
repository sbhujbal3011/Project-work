import { Injectable } from '@angular/core';
import { CustomerModel } from '../model/customer';
import { Router } from '@angular/router';
import { MerchantModel } from '../model/merchant';
import { InventoryModel } from '../model/inventory';
import { HttpClient, HttpParams } from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class CustomerDetailsService {
  customerArr: CustomerModel[];
  //cutomerObj: CustomerModel;
  merchantArr: MerchantModel[]
  inventoryArr: InventoryModel[];

  constructor(private routes: Router,private http: HttpClient, ) {
    this.customerArr = [];
    this.inventoryArr = [];
    this.merchantArr=[];
    
  }
  baseHref = "http://localhost:8888";


getCustomerDetails(){
  // this.http.get('http://localhost:8888/getMerchant').subscribe(data => {
    //console.log(data);
    return this.http.get<CustomerModel[]>(this.baseHref + "/getCustomer");
  };
 getMerchantDetails(){
 // this.http.get('http://localhost:8888/getMerchant').subscribe(data => {
   //console.log(data);
   return this.http.get<MerchantModel[]>(this.baseHref + "/getMerchant");
 };

getInventoryDetails(){
  //this.http.get('http://localhost:8888/getInventory').subscribe(data => {
   //console.log(data);
   return this.http.get<InventoryModel[]>(this.baseHref + "/getInventory");
 };
}



